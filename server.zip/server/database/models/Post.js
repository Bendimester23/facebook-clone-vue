"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
var mongodb_1 = require("mongodb");
var mongoose_1 = __importDefault(require("mongoose"));
var postSchema = new mongoose_1["default"].Schema({
    title: {
        type: String,
        min: 2,
        max: 255,
        required: true
    },
    id: {
        type: mongodb_1.ObjectId,
        min: 6,
        max: 255,
        required: true
    },
    isGlobal: {
        type: Boolean,
        required: true
    },
    text: {
        type: String,
        min: 6,
        max: 2048,
        required: true
    },
    author: {
        type: mongodb_1.ObjectId,
        min: 6,
        max: 255,
        required: true
    },
    hasImage: {
        type: Boolean,
        required: true
    }
}, {
    timestamps: true
});
exports["default"] = mongoose_1["default"].model('Post', postSchema);
