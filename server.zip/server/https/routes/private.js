"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
var jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
function verify(req, res, next) {
    var token = req.header('auth-token');
    if (!token)
        return res.status(403).send('Acces Denied');
    try {
        var verified = jsonwebtoken_1["default"].verify(token, process.env.TOKEN_SECRET);
        var expire = verified.date + 300000;
        if (expire < Date.now()) {
            console.log('expired');
            return res.status(403).send("Acces Denied: Expired token!");
        }
        req.user = verified;
        next();
    }
    catch (error) {
        console.error(error);
        res.status(403).send("Acces Denied");
    }
}
exports["default"] = verify;
